Simple example plugin for Kodi mediacenter
===

This is a simple yet fully functional example of a video plugin for [Kodi](http://kodi.tv) mediacenter.
Please read the comments in the plugin code for more details.
An installable .zip can be downloaded from "[Releases](https://github.com/romanvm/plugin.video.example/releases)" tab.

The plugin uses free sample videos are provided by [www.vidsplay.com](http://www.vidsplay.com/).

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
